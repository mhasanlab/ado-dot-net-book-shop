-- DATABASE CREATED NAME (BookShopDB)

CREATE DATABASE BookShopDB
ON 
(
    NAME = 'BookShopDB_Data',
    FILENAME = 'F:\BOOK SHOP\DB\BookShopDB_Data.mdf',
    SIZE = 25MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
)
LOG ON 
(
    NAME = 'BookShopDB_Log',
    FILENAME = 'F:\BOOK SHOP\DB\BookShopDB_Log.ldf',
    SIZE = 25MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10%
)
GO

-- Use Database

USE BookShopDB
GO

--====================================================================================
-- TABLE-01 Name (tblUser)

CREATE TABLE tblUser
(
    userName NVARCHAR(20) PRIMARY KEY NOT NULL,
    userPassword NVARCHAR(10) NOT NULL
)
GO


-- Global Table

CREATE TABLE tblGender
(
    genderID INT PRIMARY KEY NOT NULL,
    genderType NVARCHAR(10) NOT NULL
)
GO


CREATE TABLE tblBookCategory
(
    categoryID INT PRIMARY KEY NOT NULL,
    categoryType NVARCHAR (50) NOT NULL
)
GO


--====================================================================================

-- TABLE-02 Name (tblAuthors)

CREATE TABLE tblAuthors
(
    authorID INT PRIMARY KEY IDENTITY (1,1) NOT NULL,
    authorName NVARCHAR (75) NOT NULL,
    genderID INT REFERENCES tblGender(genderID),
    authorEmail NVARCHAR (50) UNIQUE,
    authorPhone NVARCHAR(50), 
    authorImage VARBINARY(MAX) NULL
)
GO



--====================================================================================

-- TABLE-03 Name (tblPublishers)

CREATE TABLE tblPublishers
(
    publisherID INT PRIMARY KEY IDENTITY (1,1) NOT NULL,
    publisherName NVARCHAR(75) NOT NULL,
    publisherAddress NVARCHAR (150) NOT NULL,
    publisherEmail NVARCHAR(30) NULL,
    publisherPhone NVARCHAR (15) NULL
)
GO

--====================================================================================


-- TABLE-04 NAME (tblBooks)

CREATE TABLE tblBooks
(
    bookID INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
    authorID INT REFERENCES tblAuthors (authorID),
    publisherID INT REFERENCES tblPublishers (publisherID),
    bookName NVARCHAR (75) NOT NULL,
    categoryID INT REFERENCES tblBookCategory (categoryID),
    bookPrice SMALLMONEY NOT NULL,
    bookImage VARBINARY(MAX) NULL,
    bookAvailable BIT DEFAULT 1
)
GO



--====================================================================================

-- TABLE-06 NAME (tblCustomers)

 CREATE TABLE tblCustomers
 (
    customerID INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
    customerName NVARCHAR (75) NOT NULL,
    genderID INT REFERENCES tblGender (genderID),
    customerLocation NVARCHAR (75) NOT NULL,
    customerEmail NVARCHAR (50) UNIQUE NULL,
    customerPhone NCHAR (11) NULL,
 )
GO



--====================================================================================

-- TABLE-07 NAME (tblsells)


CREATE TABLE tblsells
 (
    sellID INT PRIMARY KEY IDENTITY (1,1) NOT NULL,
    customerID INT REFERENCES tblCustomers (customerID) NOT NULL,
    bookID INT REFERENCES tblBooks (bookID) NOT NULL,
    sellDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    sellPrice  SMALLMONEY NOT NULL
 )
 GO

--====================================================================================

-- USE DATABASE 

USE BookShopDB
GO
--====================================================================================






